package package1;

public class Something {
	public static final int LENGTH=10;//��
	public static final int HEIGHT=20;//��
	public static final int WINDOWX=1366/2-250;
	public static final int WINDOWY=786/2-350;
	public static final int WIDTHs=500;//���ڵĿ�
	public static final int HEIGHTs=700;//���ڵĸ�
	public static final int WINDOWWIDTH=200;//�[�򴰿ڵĿ�
	public static final int WINDOWHEIGHT=400;//�[�򴰿ڵĸ�
	public static final int GAMEX=150;//�[�򴰿�x
	public static final int GAMEY=150;
	public static final int PIXEL=WINDOWWIDTH/10;//ÿ���Ŀ�
	public static final int SMALLX=GAMEX+Something.WINDOWWIDTH+10;//С����x
	public static final int SMALLY=GAMEY;//С����Y
	public static final int SMALLWIDTH=100;//С���ڿ�
	public static final int SMALLHEIGHT=100;//С���ڸ�
	/*public static void towOut(int[][] aa) {
		for (int i = 0; i < aa.length; i++) {
			for (int j = 0; j < aa[i].length; j++) {
				System.out.print(aa[i][j]+"  ");
				if(j==aa[i].length-1) {
					System.out.println();
				}
			}
		}
		System.out.println();
		
	}
	public static void towOut1(int[][] aa) {
		for (int j = aa[1].length-1; j >-1 ; j--) {
		for (int i = aa.length-1; i >-1; i--) {
			
				if(i==aa.length-1) {
					System.out.println();
				}
				System.out.print(aa[i][j]+"  ");
				
			}
		}
		System.out.println();
	}*/
	
}

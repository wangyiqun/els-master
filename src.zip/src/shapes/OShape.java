package shapes;

public class OShape extends Shape{
	public OShape() {
		int[][] value= {
				{1,1},
				{1,1},
				};
		this.value=value;
		xuanzX=1;
		xuanzY=2;
	}
	/*@Override
	public  void xuanZhuan() {
	}*/
}

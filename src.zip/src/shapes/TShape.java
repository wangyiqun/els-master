package shapes;

public class TShape extends Shape{
	public TShape() {
		int[][] value= {
				{0,1,0},
				{1,1,1},
				{0,0,0}
				};
		super.value=value;
		xuanzX=1;
		xuanzY=1;
	}
}

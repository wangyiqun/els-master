package shapes;

public class MyShape extends Shape{
	public MyShape() {
		int[][] value= {
				{1,1,1},
				{1,0,0},
				{1,1,1},
				};
		this.value=value;
		xuanzX=1;
		xuanzY=1;
	}
	
}

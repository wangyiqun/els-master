package test;

import package1.Box;
import package1.Something;

public class BoxTest {
	public static void main(String[] args) {
/*		Box box = Box.getInstance();
		for (int i = 0; i < 10; i++) {
			if (i== 5||i==6||i==9||i==10) {
				for (int j = 0; j < 11; j++) {
					if (j % 2 == 0)
						box.box[i][j] = 1;

				}
				continue;
			}
			for (int j = 0; j < 10; j++) {
				box.box[i][j] = 1;

			}
		}
		Something.towOut1(box.box);
		box.xiaoChu();
		System.out.println("����");
		Something.towOut1(box.box);*/
	}

}
